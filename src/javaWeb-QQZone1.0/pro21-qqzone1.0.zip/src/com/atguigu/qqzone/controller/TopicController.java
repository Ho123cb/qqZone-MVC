package com.atguigu.qqzone.controller;

import com.atguigu.qqzone.pojo.Topic;
import com.atguigu.qqzone.service.TopicService;
import com.atguigu.qqzone.service.impl.TopicServiceImpl;

import javax.servlet.http.HttpSession;

public class TopicController {
    TopicService topicService;
    //实现将topic存入作用域中
    public String setTopictoSession(Integer id, HttpSession session) {
        Topic topic = topicService.queryTopicById(id);
        session.setAttribute("topic",topic);
        return "frames/detail";
    }
}
