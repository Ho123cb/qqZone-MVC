package com.atguigu.qqzone.dao;

public interface HostReplyDAO {
}
