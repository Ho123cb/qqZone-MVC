package com.atguigu.qqzone.service;

import com.atguigu.qqzone.pojo.Topic;

public interface ReplyService {
    //向topic添加对应的回复列表
    public Topic addReplysToTopic(Topic topic);
}
