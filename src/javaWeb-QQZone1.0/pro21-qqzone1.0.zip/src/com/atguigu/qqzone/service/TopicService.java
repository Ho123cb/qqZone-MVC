package com.atguigu.qqzone.service;

import com.atguigu.qqzone.pojo.Topic;
import com.atguigu.qqzone.pojo.UserBasic;

import java.util.List;

public interface TopicService {
    //查询特定用户的日志列表
    List<Topic> getTopicList(UserBasic userBasic) ;
    //根据userBasic将日志列表补充到其中
    UserBasic addTopicList(UserBasic userBasic);
    //根据id查询对应的topic，要包含详细的信息
    Topic queryTopicById(Integer id);
}
