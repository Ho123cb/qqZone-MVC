package com.atguigu.qqzone.service.impl;

import com.atguigu.qqzone.dao.ReplyDAO;
import com.atguigu.qqzone.pojo.Topic;
import com.atguigu.qqzone.service.ReplyService;

public class ReplyServiceImpl  implements ReplyService {
    private ReplyDAO replyDAO;
    @Override
    public Topic addReplysToTopic(Topic topic) {
        topic.setReplyList(replyDAO.getReplyList(topic));
        return topic;
    }
}
