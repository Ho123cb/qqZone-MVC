package com.atguigu.myssm.ioc;

public interface BeanFactory {
    Object getBean(String id);
}
